# project-quiz
 static quiz in javascript
 there are 3 quizes to test your javascript knowledge. Results are shown when you click the submit button.
 HTML and Javascript used in this project.
