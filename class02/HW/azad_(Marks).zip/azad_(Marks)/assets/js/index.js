


var x =parseFloat( prompt("Enter any digit:"));
var result;
result(x);
function result(mark){
    if(mark>100){
        alert("Invalid mark ="+mark);
    }
    else if(mark>=80 && mark<=100){
        alert("You have A+ ="+ mark);
    }
    else if(mark>=75 && mark<=79){
        alert("You have A = "+mark);
    }
    else if(mark>=70 && mark<=74){
        alert("You have A- "+ mark);
    }
    else if(mark>=65 && mark<=69){
        alert("You have B+ = "+mark);
    }
    else if(mark>=60 && mark<=64){
        alert("You have B = "+ mark);
    }
    else if(mark>=55 && mark<=59){
        alert("You have B- = "+ mark);
    }
    else if(mark>=50 && mark<=54){
        alert("You have C+ = "+ mark);
    }
    else if(mark>=45 && mark<=44){
        alert("You have D = "+ mark);
    }
    else if(mark>=33 && mark<=39){
        alert("You have only Passed = "+ mark);
    }
    else if(mark<=32){
        alert("Sorry, You have Failed = " + mark);
    }
  
}


